package com.test.saeideh.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.R;

import java.util.List;


/**
 * Created by Mehdi on 06/04/2018.
 */

public class rviewAdapter extends RecyclerView.Adapter<rviewAdapter.ViewHolder> {
    private List<User> localImages;//// Cached copy of localImages
    private Context mContext;
    private intOnItemClkListener onItemClkListener;


    public rviewAdapter(final Context mContext, final List<User> images) {
        this.mContext = mContext;
        this.localImages = images;
        //

        onItemClkListener = new intOnItemClkListener() {
            @Override
            public void onContainerClick(int position) {

            }


        };

    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        View itemView;

        itemView = layoutInflater.inflate(R.layout.item_rview, parent, false);


        ViewHolder viewHolder = new ViewHolder(itemView);
        viewHolder.setListener(onItemClkListener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int position) {

        if (localImages != null) {
            User model = localImages.get(position);

            String id = model.getId();
            viewHolder.txtId.setText(id);

        } else {
            // Covers the case of data not being ready yet.
            viewHolder.txtId.setText("No list");
        }


    }


    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (localImages != null)
            return localImages.size();
        else return 0;
    }


    static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private intOnItemClkListener listener;
        private TextView txtId;


        ViewHolder(View itemView) {
            super(itemView);
            txtId = itemView.findViewById(R.id.txt_id);


            itemView.setOnClickListener(this);


        }

        void setListener(intOnItemClkListener listener) {
            this.listener = listener;
        }

        @Override
        public void onClick(View view) {
            switch (view.getId()) {

                default://:container clicked
                    listener.onContainerClick(getAdapterPosition());
                    break;
            }
        }


    }


    public interface intOnItemClkListener {
        void onContainerClick(int position);

    }

}