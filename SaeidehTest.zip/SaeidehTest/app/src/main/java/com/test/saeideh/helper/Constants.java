package com.test.saeideh.helper;

public class Constants {
    public static final String DB_NAME = "mydb";
    public static final String TABLE_NAME_USER = "User";
}
