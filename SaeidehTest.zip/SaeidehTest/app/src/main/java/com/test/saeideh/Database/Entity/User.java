package com.test.saeideh.Database.Entity;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.test.saeideh.helper.Constants;

import java.util.Objects;

@Entity(tableName = Constants.TABLE_NAME_USER)
public class User {

    @PrimaryKey
    @NonNull
    private String id;
    @ColumnInfo(name = "name")
    private String name;

    public User(String id, String name) {
        this.id = id;
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;

        User user = (User) o;

        if (!id.equals(user.id)) return false;
        return Objects.equals(name, user.name);
    }


    @Override
    public String toString() {
        return "Image{" +
                "id=" + id +
                ", download_url='" + name + '\'' +
                '}';
    }

    @NonNull
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
