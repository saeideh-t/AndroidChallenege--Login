package com.test.saeideh.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.R;
import com.test.saeideh.Repository.Repository;
import com.test.saeideh.helper.UserSessionHelper;

public class MainActivity extends AppCompatActivity {

    private UserSessionHelper sessionHelper;
    private Button btnLogout;
    private Button btnAdd;
    private Button btnAll;
    private Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogout = findViewById(R.id.btn_logout);
        btnAdd = findViewById(R.id.btn_add);
        btnAll = findViewById(R.id.btn_all);
        repository = new Repository(this);


        sessionHelper = UserSessionHelper.getInstance(this);
        sessionHelper.setContext(this);
        sessionHelper.checkForLogin();

        btnLogout.setOnClickListener(view -> {
            sessionHelper.logout();
        });

        btnAdd.setOnClickListener(view -> {
            addItemToDb(new User(String.valueOf((int) (Math.random() * 1000)),"user name"));
        });

        btnAll.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this,FavoritesActivity.class);
            startActivity(intent);
        });

    }

    private void addItemToDb(User user) {

        repository.insert(user);

    }
}
