package com.test.saeideh.Repository;

import android.content.Context;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.test.saeideh.Database.Dao.UserDao;
import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.Database.MyDatabase;

import java.util.List;

import io.reactivex.Single;

public class Repository {

    private UserDao mUserDao;
    private List<User> mAll;
    private User mItem;
    private Context mContext;

    public Repository(Context mContext) {
        this.mContext = mContext;
        MyDatabase db = MyDatabase.getInstance(mContext);
        mUserDao = db.userDao();
        mAll =  mUserDao.getAll();
    }


    public List<User> getAll() {
        return mAll;
    }

    public void nukeTable() {
        mUserDao.nukeTable();
    }

    public User getItem() {
        return mItem;
    }


    public Single<Integer> delete(User image) {
        return mUserDao.delete(image);
        //create worker thread to insert/delete data into database
//        new operationAsyncTask(mImageDao, "d").execute(image);

    }

    public Long insert(User image) {
        return mUserDao.insert(image);
        //create worker thread to insert/delete data into database
//        new operationAsyncTask(mImageDao, "i").execute(image);
    }


    //network methods


}
