package com.test.saeideh.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.Task;
import com.test.saeideh.R;
import com.test.saeideh.helper.SignWithGoogleHelper;
import com.test.saeideh.helper.UserSessionHelper;

import static com.test.saeideh.helper.SignWithGoogleHelper.RC_SIGN_IN;


public class LoginActivity extends AppCompatActivity {


    private Context mContext;
    private SignInButton btnSignIn;
    private SignWithGoogleHelper signWithGoogleHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initData();
    }


    private void initData() {
        mContext = this;
        UserSessionHelper.getInstance(mContext).setContext(mContext);
        btnSignIn = findViewById(R.id.sign_in_button);
        signWithGoogleHelper = SignWithGoogleHelper.getInstance(mContext);
        signWithGoogleHelper.setContext(this);
        btnSignIn.setOnClickListener(v -> startActivityForResult(signWithGoogleHelper.getSignInIntent(), RC_SIGN_IN));


    }



    @Override
    public void onBackPressed() {
//        super.onBackPressed();//
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            signWithGoogleHelper.handleSignInResult(task);

        }
    }
}
