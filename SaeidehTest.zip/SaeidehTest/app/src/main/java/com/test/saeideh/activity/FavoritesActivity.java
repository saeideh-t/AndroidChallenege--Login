package com.test.saeideh.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;

import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.Database.MyDatabase;
import com.test.saeideh.R;
import com.test.saeideh.Repository.Repository;
import com.test.saeideh.adapter.rviewAdapter;

import java.util.List;

public class FavoritesActivity extends AppCompatActivity {

    private MyDatabase myDatabase;
    private Context mContext;
    private RecyclerView rview;
    private rviewAdapter adapter;
    private Repository repository;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        initData();
        setupRview(repository.getAll());
    }

    private void initData() {
        mContext = this;
        myDatabase = MyDatabase.getInstance(mContext);
        repository = new Repository(this);
        rview = findViewById(R.id.rview);

    }




    private void setupRview(List<User> users) {
        rview.setLayoutManager(new LinearLayoutManager(mContext));
        adapter = new rviewAdapter(mContext, users);
        rview.setAdapter(adapter);
    }
}
