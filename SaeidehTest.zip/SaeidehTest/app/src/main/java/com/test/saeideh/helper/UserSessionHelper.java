package com.test.saeideh.helper;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.test.saeideh.Database.MyDatabase;
import com.test.saeideh.R;
import com.test.saeideh.Repository.Repository;
import com.test.saeideh.activity.LoginActivity;


public class UserSessionHelper {

    private static UserSessionHelper SESSION;
    private final SharedPreferences.Editor editor;
    private Context mContext;
    private SharedPreferences sharedPrefAccount;


    public static UserSessionHelper getInstance(Context mContext) {
        if (SESSION == null) {
            SESSION = new UserSessionHelper(mContext);
        }
        return SESSION;
    }


    private UserSessionHelper(Context mContext) {
        this.mContext = mContext;
        sharedPrefAccount = mContext.getSharedPreferences(
                mContext.getString(R.string.preference_account), Context.MODE_PRIVATE);
        editor = sharedPrefAccount.edit();
    }


    public boolean checkForLogin() {
        if (isLogin()) {
            return true;
        } else {
            onLogoutSuccess();
            return false;
        }
    }

    public boolean isLogin() {
        return sharedPrefAccount.getBoolean("islogin", false);// false is default value
    }

    private void setIsLogin() {
        editor.putBoolean("islogin", true);
        editor.apply();
    }


    private void setEmail(String email) {
        if (email == null) return;
        editor.putString("email", email);
        editor.apply();
    }

    public String getFullName() {
        return sharedPrefAccount.getString("full_name", "");
    }

    private void setFullName(String full_name) {
        editor.putString("full_name", full_name);
        editor.apply();
    }


    private void clear() {
        editor.clear();
        editor.apply();
    }


    public void logout() {
        // signOut from google
        SignWithGoogleHelper.getInstance(mContext).signOut();

    }


    public void onLogoutSuccess() {

        //clear sh.pref.
        clear();

        //clear db
         new Repository(mContext).nukeTable();//TODO if gToken expired --> db will be cleared!!!


        Intent intent = new Intent(mContext, LoginActivity.class);
        mContext.startActivity(intent);


    }


    public void onLoginSuccess(GoogleSignInAccount authModel) {

        setIsLogin();
        setEmail(authModel.getEmail());

        //redirect to main activity
        if (mContext instanceof LoginActivity) {
            ((LoginActivity) mContext).finish();
        }


    }

    public void setContext(Context mContext) {
        this.mContext = mContext;
    }


}

