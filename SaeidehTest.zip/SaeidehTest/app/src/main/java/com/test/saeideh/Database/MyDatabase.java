package com.test.saeideh.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.test.saeideh.Database.Dao.UserDao;
import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.helper.Constants;


//https://github.com/googlecodelabs/android-room-with-a-view/
// blob/master/app/src/main/java/com/example/android/roomwordssample/WordRoomDatabase.java

@Database(entities = {User.class}, version = 1)
public abstract class MyDatabase extends RoomDatabase {


    // marking the instance as volatile to ensure atomic access to the variable
    private static volatile MyDatabase INSTANCE;

    public abstract UserDao userDao();
    //TODO define other DAOs ...

    public static MyDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            INSTANCE = buildDatabaseInstance(context);
        }
        return INSTANCE;
    }

    private static MyDatabase buildDatabaseInstance(Context context) {
        synchronized (MyDatabase.class) {
            if (INSTANCE == null) {
                INSTANCE = Room.databaseBuilder(context,
                        MyDatabase.class, Constants.DB_NAME)
                        .allowMainThreadQueries()//TODO
                        .build();
            }
            return INSTANCE;
        }

    }

    public void cleanUp() {
        INSTANCE = null;
    }
}
