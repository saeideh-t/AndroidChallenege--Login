package com.test.saeideh.Database.Dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.test.saeideh.Database.Entity.User;
import com.test.saeideh.helper.Constants;

import java.util.List;
import java.util.Observable;

import io.reactivex.Completable;
import io.reactivex.Single;

@Dao
public interface UserDao {


    @Query("SELECT * FROM " + Constants.TABLE_NAME_USER)
    List<User> getAll();
    /*Later in this codelab, you create an Observer of the data in the onCreate() method
    of MainActivity and override the observer's onChanged() method. When the LiveData changes,
    the observer is notified and onChanged() is executed. You will then update the cached data
    in the adapter, and the adapter will update what the user sees.
    * */

    @Query("DELETE FROM " + Constants.TABLE_NAME_USER)
    public void nukeTable();

    /*
     * Insert the object in database
     * @param note, object to be inserted
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    Long insert(User user);

    /*
     * update the object in database
     * @param note, object to be updated
     */
    @Update
    void update(User repos);

    /*
     * delete the object from database
     * @param note, object to be deleted
     */
    @Delete
    Single<Integer> delete(User user);

    /*
     * delete list of objects from database
     * @param note, array of objects to be deleted
     */
    @Delete
    void delete(User... user);      // Note... is varargs, here note is an array

}
