package com.test.saeideh.helper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import androidx.annotation.NonNull;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.test.saeideh.R;


public class SignWithGoogleHelper {

    private Context mContext;
    private GoogleSignInClient mGoogleSignInClient;
    public static final int RC_SIGN_IN = 1500;
    private static SignWithGoogleHelper signInHelper;
    private GoogleSignInOptions gso;
    private Intent signInIntent;
    private UserSessionHelper sessionHelper;


    public static SignWithGoogleHelper getInstance(Context mContext) {
        if (signInHelper == null) {
            signInHelper = new SignWithGoogleHelper(mContext);
        }
        return signInHelper;
    }

    private SignWithGoogleHelper(Context mContext) {
        this.mContext = mContext;
        init();
    }

    public void setContext(Context mContext) {
        this.mContext = mContext;
    }

    private void init() {
        // Configure sign-in to request the user's ID, email address, and basic
        // profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestIdToken(mContext.getString(R.string.server_client_id))//https://developers.google.com/identity/sign-in/android/backend-auth#send-the-id-token-to-your-server
                .requestEmail()
                .build();
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(mContext, gso);
        signInIntent = mGoogleSignInClient.getSignInIntent();
        sessionHelper = UserSessionHelper.getInstance(mContext);
    }


    private void updateUi(GoogleSignInAccount account) {
        if (account == null) {//means user is not signed in yet
            onUserSignedOut();
        } else {//means user is already signed in
            //user is now signed in
            sessionHelper.onLoginSuccess(account);
//            sendTokenToServer(account.getIdToken());//TODO TIP: if you don't need confirmation from server, you can call onLoginSuccess directly.
//            saveGAccountInfo(account);//

        }
    }

    //TODO TIP it should be called from MainActivity@onStart to check token status of google token
    //TIP in case you depends on server token instead of google token you don't need this
    public void checkLoginStatus() {
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(mContext);
        if (account == null) {
            refreshIdToken();
        }
//        updateUi(account);
    }



    public void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            updateUi(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
//            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            updateUi(null);
        }
    }



    //  TODO LATER  https://developers.google.com/identity/sign-in/android/disconnect#disconnect_accounts
    private void revokeAccess() {
        mGoogleSignInClient.revokeAccess()
                .addOnCompleteListener((Activity) mContext, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        sessionHelper.onLogoutSuccess();
                    }
                });
    }

    public void signOut() {
        mGoogleSignInClient.signOut()
                .addOnCompleteListener((Activity) mContext, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        revokeAccess();
//                        onUserSignedOut();
                    }
                });
    }

    private void onUserSignedOut() {
        sessionHelper.onLogoutSuccess();
    }

    //    Google ID tokens are issued for one hour validity and will expire, you can simply use silentSignIn in your app to get a new one without any user interaction.
    public void refreshIdToken() {
        // Attempt to silently refresh the GoogleSignInAccount. If the GoogleSignInAccount
        // already has a valid token this method may complete immediately.
        //
        // If the user has not previously signed in on this device or the sign-in has expired,
        // this asynchronous branch will attempt to sign in the user silently and get a valid
        // ID token. Cross-device single sign on will occur in this branch.
        mGoogleSignInClient.silentSignIn()
                .addOnCompleteListener(
                        (Activity) mContext,
                        new OnCompleteListener<GoogleSignInAccount>() {
                            @Override
                            public void onComplete(@NonNull Task<GoogleSignInAccount> task) {
                                handleSignInResult(task);
                            }
                        });

    }

    public Intent getSignInIntent() {
        return signInIntent;
    }


}
